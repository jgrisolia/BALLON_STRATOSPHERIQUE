Arduino.h and pgmspace.h included in IDE 

Installing libraries for Arduino:
http://arduino.cc/en/Guide/Libraries